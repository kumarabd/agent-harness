{{- define "agent-brain.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "agent-brain.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "agent-brain.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
{{- end }}

{{- define "agent-brain.labels" -}}
helm.sh/chart: {{ include "agent-brain.chart" . }}
{{ include "agent-brain.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "agent-brain.selectorLabels" -}}
app.kubernetes.io/name: {{ include "agent-brain.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "agent-brain.componentLabels" -}}
{{ include "agent-brain.selectorLabels" . }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{- define "agent-brain.image" -}}
{{- $root := .context -}}
{{- $component := .component -}}
{{- $tag := $root.Values.image.tag | default $root.Chart.AppVersion -}}
{{ printf "%s/%s/agent-brain-%s:%s" $root.Values.image.registry $root.Values.image.repositoryOwner $component $tag }}
{{- end }}

{{- define "agent-brain.secretName" -}}
{{- if .Values.existingSecret }}
{{- .Values.existingSecret }}
{{- else if .Values.secret.name }}
{{- .Values.secret.name }}
{{- else }}
{{- include "agent-brain.fullname" . }}
{{- end }}
{{- end }}

{{- define "agent-brain.secret.postgresDSN" -}}
{{- .Values.secret.postgresDSN | default .Values.database.postgresDSN -}}
{{- end }}

{{- define "agent-brain.secret.redisAddr" -}}
{{- .Values.secret.redisAddr | default .Values.database.redisAddr -}}
{{- end }}

{{- define "agent-brain.secret.litellmAPIKey" -}}
{{- .Values.secret.litellmAPIKey | default .Values.embed.litellmAPIKey -}}
{{- end }}

{{- define "agent-brain.secret.miningLLMAPIKey" -}}
{{- .Values.secret.miningLLMAPIKey | default .Values.mining.llm.apiKey -}}
{{- end }}

{{- define "agent-brain.secret.jwtSecret" -}}
{{- .Values.secret.jwtSecret | default .Values.auth.jwtSecret -}}
{{- end }}

{{- define "agent-brain.secret.apiKeys" -}}
{{- .Values.secret.apiKeys | default "" -}}
{{- end }}

{{- define "agent-brain.secret.adminSecret" -}}
{{- .Values.secret.adminSecret | default "" -}}
{{- end }}

{{- define "agent-brain.iamBootstrapEnabled" -}}
{{- and (default true .Values.iam.bootstrapEnabled) (include "agent-brain.secret.apiKeys" .) -}}
{{- end }}

{{- define "agent-brain.configMapName" -}}
{{- if .Values.config.existingConfigMap }}
{{- .Values.config.existingConfigMap }}
{{- else }}
{{- include "agent-brain.fullname" . }}-config
{{- end }}
{{- end }}

{{- define "agent-brain.domainsConfigPath" -}}
{{- printf "%s/%s" .Values.config.mountPath .Values.config.domainsFile -}}
{{- end }}

{{- define "agent-brain.env" -}}
- name: POSTGRES_DSN
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: postgres-dsn
- name: REDIS_ADDR
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: redis-addr
- name: EMBED_ENABLED
  value: {{ .Values.embed.enabled | quote }}
- name: LITELLM_BASE_URL
  value: {{ .Values.embed.litellmBaseURL | quote }}
- name: LITELLM_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: litellm-api-key
      optional: true
- name: EMBED_MODEL
  value: {{ .Values.embed.model | quote }}
- name: EMBED_DIM
  value: {{ .Values.embed.dim | quote }}
- name: DOMAINS_CONFIG_PATH
  value: {{ include "agent-brain.domainsConfigPath" . | quote }}
- name: AUTH_REQUIRED
  value: {{ .Values.auth.required | quote }}
- name: JWT_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: jwt-secret
{{- include "agent-brain.envCors" . }}
{{- if include "agent-brain.secret.adminSecret" . }}
- name: ADMIN_SECRET
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: admin-secret
{{- end }}
- name: DREAM_INTERVAL
  value: {{ .Values.dreaming.interval | default "4h" | quote }}
- name: DREAM_REGISTRY_SIMILARITY_THRESHOLD
  value: {{ .Values.dreaming.registrySimilarityThreshold | default "0.92" | quote }}
{{- end }}

{{- define "agent-brain.envCors" -}}
{{- if .Values.cors }}
- name: CORS_ENABLED
  value: {{ .Values.cors.enabled | quote }}
{{- if .Values.cors.allowedOrigins }}
- name: CORS_ALLOWED_ORIGINS
  value: {{ .Values.cors.allowedOrigins | quote }}
{{- end }}
{{- end }}
{{- end }}

{{- define "agent-brain.envExplorer" -}}
{{- if .Values.explorer.publicMCPUrl }}
- name: EXPLORER_PUBLIC_MCP_URL
  value: {{ .Values.explorer.publicMCPUrl | quote }}
{{- end }}
{{- if .Values.explorer.installScriptUrl }}
- name: EXPLORER_INSTALL_SCRIPT_URL
  value: {{ .Values.explorer.installScriptUrl | quote }}
{{- end }}
{{- if .Values.explorer.repoRawBase }}
- name: EXPLORER_REPO_RAW_BASE
  value: {{ .Values.explorer.repoRawBase | quote }}
{{- end }}
{{- if .Values.explorer.clerkJWKSUrl }}
- name: CLERK_JWKS_URL
  value: {{ .Values.explorer.clerkJWKSUrl | quote }}
{{- end }}
{{- if .Values.explorer.clerkIssuer }}
- name: CLERK_ISSUER
  value: {{ .Values.explorer.clerkIssuer | quote }}
{{- end }}
{{- end }}

{{- define "agent-brain.envIamBootstrap" -}}
{{- if include "agent-brain.iamBootstrapEnabled" . }}
- name: API_KEYS
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" . }}
      key: api-keys
{{- end }}
{{- end }}

{{- define "agent-brain.configVolume" -}}
{{- if .Values.config.existingSecret }}
- name: config
  secret:
    secretName: {{ .Values.config.existingSecret }}
    defaultMode: 0444
{{- else if or .Values.config.create .Values.config.existingConfigMap }}
- name: config
  configMap:
    name: {{ include "agent-brain.configMapName" . }}
    defaultMode: 0444
{{- end }}
{{- end }}

{{- define "agent-brain.configMount" -}}
{{- if or .Values.config.existingSecret (or .Values.config.create .Values.config.existingConfigMap) }}
- name: config
  mountPath: {{ .Values.config.mountPath | quote }}
  readOnly: true
{{- end }}
{{- end }}

{{- /*
Shared env for the Temporal worker (Deployment + its schedule-sync hook Job both need
exactly this) — Postgres + LiteLLM (same as every prior worker), plus Temporal connection
settings. This chart doesn't deploy Temporal itself; .Values.temporal.address must point at
an existing cluster. One process now runs both the mining and EMU pipelines, each on its
own task queue (see workers/temporal-worker/worker.py) — both queue names are always
passed, not selected by the caller: include "agent-brain.temporalWorkerEnv" (dict "context" $)
*/ -}}
{{- define "agent-brain.temporalWorkerEnv" -}}
{{- $root := .context -}}
- name: POSTGRES_DSN
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" $root }}
      key: postgres-dsn
- name: LITELLM_BASE_URL
  value: {{ $root.Values.embed.litellmBaseURL | quote }}
- name: LITELLM_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" $root }}
      key: litellm-api-key
      optional: true
- name: EMBED_MODEL
  value: {{ $root.Values.embed.model | quote }}
- name: LLM_BASE_URL
  value: {{ $root.Values.mining.llm.baseURL | quote }}
- name: LLM_MODEL
  value: {{ $root.Values.mining.llm.model | quote }}
- name: LLM_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ include "agent-brain.secretName" $root }}
      key: mining-llm-api-key
      optional: true
- name: TEMPORAL_ADDRESS
  value: {{ $root.Values.temporal.address | quote }}
- name: TEMPORAL_NAMESPACE
  value: {{ $root.Values.temporal.namespace | quote }}
- name: TEMPORAL_MINING_TASK_QUEUE
  value: {{ $root.Values.temporal.miningTaskQueue | quote }}
- name: TEMPORAL_EMU_TASK_QUEUE
  value: {{ $root.Values.temporal.emuTaskQueue | quote }}
- name: TEMPORAL_TLS
  value: {{ $root.Values.temporal.tls | quote }}
{{- if $root.Values.temporal.apiKeySecretName }}
- name: TEMPORAL_API_KEY
  valueFrom:
    secretKeyRef:
      name: {{ $root.Values.temporal.apiKeySecretName }}
      key: temporal-api-key
{{- end }}
{{- end }}

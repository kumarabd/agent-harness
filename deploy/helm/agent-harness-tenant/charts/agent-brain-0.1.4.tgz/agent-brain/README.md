# agent-brain Helm chart

Deploy agent-brain against **existing** Postgres (no datastore subcharts).

## Workloads

| Component | Kind | Purpose |
|-----------|------|---------|
| `server` | Deployment + Service | Go MCP monolith (SSE, port 8080) |
| `migrate` | Job (pre-install/pre-upgrade hook) | Applies Postgres migrations |
| `temporalWorker` | Deployment | Python — mining + EMU pipelines, one process, two Temporal task queues |
| `sync-schedules` | Job (post-install/post-upgrade hook) | Idempotently upserts the worker's Temporal Schedules |

Not included: Ingress, HPA, ServiceMonitor. This chart connects to an **existing** Temporal cluster (`temporal.address`) — it does not deploy Temporal itself.

## Install

```bash
helm upgrade --install agent-brain ./charts/agent-brain \
  --namespace agent-brain --create-namespace \
  --set image.tag=0.1.2 \
  --set secret.postgresDSN='postgres://...' \
  --set secret.jwtSecret='...' \
  --set secret.apiKeys='bootstrap-key:your-user-id' \
  --set explorer.publicMCPUrl='https://agent-memory.example.com/sse' \
  --set cors.allowedOrigins='https://explorer.example.com' \
  --set explorer.clerkIssuer='https://your-instance.clerk.accounts.dev' \
  --set temporal.address='temporal-frontend:7233'
```

**Minimal:**

```bash
helm upgrade --install agent-brain ./charts/agent-brain \
  -f charts/agent-brain/values-minimal.yaml \
  --namespace agent-brain --create-namespace
```

Pair with **agent-web** for onboarding (`/onboarding`) and Settings (same namespace).

## Values reference

| Key | Purpose |
|-----|---------|
| `secret.postgresDSN` | Postgres connection |
| `secret.jwtSecret` | HS256 JWT for MCP / explorer |
| `secret.apiKeys` | **Bootstrap only** — `key:user-id,...` seeded into `iam_api_keys` on API pod start |
| `iam.bootstrapEnabled` | Set `API_KEYS` env on the server pod (default `true`) |
| `auth.required` | Require JWT or API key on SSE |
| `cors.enabled` | Emit CORS headers (default `true` when origins set) |
| `cors.allowedOrigins` | Comma list or `*` (browser clients, e.g. agent-web on another host) |
| `config.*` | Domains JSON ConfigMap only |
| `explorer.publicMCPUrl` | Onboarding API + plugin env |
| `explorer.installScriptUrl` | Cursor `install.sh` URL |
| `explorer.repoRawBase` | Raw GitHub base for docs/templates |
| `explorer.clerkIssuer` | Clerk JWT issuer → JWKS at `/.well-known/jwks.json` |
| `explorer.clerkJWKSUrl` | Explicit JWKS URL (overrides issuer-derived URL) |
| `migrate.enabled` | Pre-upgrade migrate Job (includes `00030_iam.sql`) |

## CORS (direct API exposure)

When **agent-web** calls this API from a public origin (not nginx same-origin proxy), set:

```yaml
cors:
  enabled: true
  allowedOrigins: "https://explorer.example.com"
```

Set `cors.enabled: false` to omit CORS headers entirely.

## Clerk + Explorer API

| Endpoint | Auth |
|----------|------|
| `POST /v1/explorer/auth/session` | Clerk Bearer JWT → explorer HS256 JWT |
| `GET /v1/explorer/me` | Explorer JWT / API key |
| `GET /v1/explorer/settings/onboarding` | Explorer JWT / API key (platforms: cursor, claude_code, openclaw) |

Configure `explorer.clerkIssuer` (or `clerkJWKSUrl`) on the server pod.

## Postgres IAM

| Table | Purpose |
|-------|---------|
| `iam_users` | Tenant (`user_id`) |
| `iam_service_accounts` | Per-user agents (`X-Agent-ID`) |
| `iam_domain_acl` | Per-user domain write rules (default `*/*`) |
| `iam_api_keys` | Hashed API keys |

- **No** `AGENT_POLICY_PATH` / policy ConfigMap.
- Register agents in **Memory Explorer → /onboarding** or Settings.
- `secret.apiKeys` only **seeds** at startup; use Settings for more keys.

Workers and CronJobs use Postgres for policy but do **not** receive `API_KEYS` env.

Python mining + EMU processing runs as one consolidated Temporal worker process (`workers/temporal-worker`, a single `Deployment`, see `temporalWorker:`/`temporal:` values) — two task queues (`agent-brain-mining`, `agent-brain-emu`), no shared workflow/activity registration between the two pipelines. Temporal Schedules (cron) drive execution timing, not Kubernetes CronJobs. This chart connects to an existing Temporal cluster (`temporal.address`); it does not deploy Temporal itself. A post-install/post-upgrade hook Job keeps all 7 schedules (5 mining + 2 EMU) in sync with the worker's declared cron strings on every release.

## Domains

| Env | Source |
|-----|------|
| `DOMAINS_CONFIG_PATH` | ConfigMap `{{ release }}-agent-brain-config` → `/config/domains.json` |

## existingSecret

When `secret.create: false` and `existingSecret: my-secret`, provide keys:

- `postgres-dsn`, `jwt-secret`
- optional `litellm-api-key`
- optional `api-keys` (bootstrap string `key:user-id,...`)

## Images

`ghcr.io/<repositoryOwner>/agent-brain-<component>:<tag>`

Components: `server`, `migrate`, `worker-temporal`.

---
name: system-ops
description: "How this user's system incident/maintenance log is structured in Notion, and the standing principles for logging issues, diagnoses, and fixes."
tags: [sre, systems, maintenance, notion]
---

# System Ops — Notion Structure & Principles

This user tracks system incidents and maintenance entirely in Notion, under
one hub page: **🖥️ System Ops** (`3ac71330-52bb-817b-9f19-fe4585817cb7`).

## Page structure

- **Incidents** (data source `1bb1f403-baf0-4526-9b96-193bb574baee`) — one row
  per incident: `Name` (title, short description of the issue), `Date`,
  `Symptom` (text — what was observed), `Root Cause` (text — filled in once
  diagnosed; leave blank or "unknown" if unresolved), `Fix Applied` (text),
  `Status` (select: Open / Resolved / Monitoring), `Severity` (select: Low /
  Medium / High), `Notes`.

## Core principles

These are standing constraints, not suggestions:

1. **Notion is the default recording surface.** Log incidents and fixes
   there without being asked each time.
2. **Diagnose before you fix.** Check logs, process state, or resource
   usage before naming a root cause — never guess at one you haven't
   verified.
3. **One row per incident.** Never a rollup or summary row — history and
   pattern queries depend on one row per incident.
4. **Ask before anything destructive or hard to reverse** — killing a
   process, deleting files, restarting a service, applying an update. Say
   what you're about to do and why, unless it's already been authorized.
5. **Read recent Incidents history before diagnosing a new report.** A
   "new" symptom may be a repeat — check before treating it as novel.
6. **Flag recurring or worsening issues** (e.g. "this crashes every Monday")
   when you notice the pattern in the log.

Applying these principles to a specific task (triaging a new report,
closing out a resolved incident, reviewing recent history) is left to your
own troubleshooting judgment — there is deliberately no separate
step-by-step workflow section per incident type here.

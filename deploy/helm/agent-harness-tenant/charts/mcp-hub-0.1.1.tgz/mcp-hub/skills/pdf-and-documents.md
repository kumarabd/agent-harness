---
name: pdf-and-documents
description: "Extract text from PDFs and scanned documents — when to use pymupdf, the ocr_pdf tool, or marker-pdf, and how to invoke each."
tags: [pdf, ocr, documents, extraction]
---

# PDF & Document Extraction

pymupdf and marker-pdf are already installed in this environment (baked
into the image at build time, including marker-pdf's OCR models) — no
`pip install` needed before using either.

## Step 1: Remote URL available?

If the document has a URL, always try `web_extract` first:

```
web_extract(urls=["https://arxiv.org/pdf/2402.03300"])
web_extract(urls=["https://example.com/report.pdf"])
```

This handles PDF-to-markdown conversion with no local dependencies. Only
use local extraction below when the file is local, `web_extract` fails,
or you need batch processing.

## Step 2: Choose an extractor

| Content type | Path |
|---|---|
| Text-based PDF | pymupdf — exact, instant, no model call. Always prefer this when the PDF has a real text layer; never OCR text that's already machine-readable data (this matters most for numeric data like bank statements — an OCR misread digit is a real failure mode pymupdf doesn't have). |
| Scanned / image-only PDF | `ocr_pdf` tool (backend: `utility`) — call via `search_tools`/`call_tool`, passing the PDF as base64. Returns transcribed text with `--- page N ---` markers. |
| Tables, equations, forms, complex layout | marker-pdf (below) — a dedicated layout model, not a raw OCR transcription tool. |
| `ocr_pdf` call fails or is unreachable | fall back to marker-pdf (below). |

## pymupdf — inline Python, no helper script

```python
import pymupdf
doc = pymupdf.open("document.pdf")
for page in doc:
    print(page.get_text())
```

Markdown output:

```python
import pymupdf4llm
print(pymupdf4llm.to_markdown("document.pdf"))
```

Split, merge, and search all work natively, no extra dependencies:

```python
# Split: extract pages 1-5 to a new PDF
import pymupdf
doc = pymupdf.open("report.pdf")
new = pymupdf.open()
for i in range(5):
    new.insert_pdf(doc, from_page=i, to_page=i)
new.save("pages_1-5.pdf")
```

```python
# Merge multiple PDFs
import pymupdf
result = pymupdf.open()
for path in ["a.pdf", "b.pdf", "c.pdf"]:
    result.insert_pdf(pymupdf.open(path))
result.save("merged.pdf")
```

```python
# Search for text across all pages
import pymupdf
doc = pymupdf.open("report.pdf")
for i, page in enumerate(doc):
    results = page.search_for("revenue")
    if results:
        print(f"Page {i+1}: {len(results)} match(es)")
        print(page.get_text("text"))
```

## Scanned/image-only PDFs — `ocr_pdf` tool

```
search_tools(query="OCR a scanned PDF")
call_tool(server="utility", tool="ocr_pdf", arguments={"pdf_base64": "<base64-encoded PDF bytes>"})
```

Returns the transcribed text as a single string, pages separated by
`--- page N ---`. If the call fails (backend unreachable, error response),
or the document needs table/equation/form structure rather than raw
transcription, use marker-pdf instead.

## marker-pdf — installed CLI, no helper script

```bash
marker_single document.pdf --output_dir ./output       # Markdown
marker_single scanned.pdf --output_dir ./output         # Scanned PDF (OCR)
marker /path/to/folder --workers 4                      # Batch
```

marker-pdf's OCR models are already downloaded and baked into this
image — the first call in production is not slower than any other.

## Other formats

- **Word (DOCX)**: use `python-docx` — parses actual document structure,
  far better than OCR:
  ```python
  import docx
  doc = docx.Document("file.docx")
  print("\n".join(p.text for p in doc.paragraphs))
  ```
- **PowerPoint (PPTX)**: out of scope for this skill — no `powerpoint`
  skill exists in this skill-hub today.

## Notes

- `web_extract` is always the first choice for URLs.
- pymupdf is the safe default for text-based PDFs — instant, no model
  call, exact.
- `ocr_pdf` is the default for scanned/image-only PDFs.
- marker-pdf is for tables, equations, forms, complex layout, and as the
  fallback when `ocr_pdf` fails.
- Applying this to a specific task (extracting one document, batch
  processing a folder) is left to your own judgment — there is
  deliberately no separate step-by-step workflow section per task type.

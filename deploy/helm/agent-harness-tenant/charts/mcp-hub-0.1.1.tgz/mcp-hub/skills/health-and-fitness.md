---
name: health-and-fitness
description: "How this user's health & fitness data is structured in Postgres (via the health backend's tools), and the workflow for planning workouts, logging meals/check-ins, and reading goals & preferences before acting."
tags: [fitness, health, planning, postgres]
---

# Health & Fitness — Postgres Structure & Workflow

This user tracks health and fitness in a dedicated Postgres database,
reachable through mcp-hub's `health` backend. Use `search_tools`/`call_tool`
to reach its tools — never assume a tool name without discovering it first.

## Core requirements

These are standing constraints, not suggestions — they came directly from
the user and each one exists for a reason surfaced during actual use:

1. **The health tools are the default recording surface.** Log workouts,
   meals, and check-ins there without being asked each time — don't wait
   for an explicit "log this."
2. **Look at previous workouts before planning new ones.** Never propose a
   workout in a vacuum — pull recent history first via `workouts_read`.
3. **Account for current health conditions before planning.** Injuries,
   illness, poor sleep, or fatigue override the default plan — reduce,
   substitute, or rest instead of following the "default" progression.
4. **Never guess or fabricate a personal health fact.** Weight, body fat,
   sleep, resting HR, and similar biometric values are real facts about the
   user, not something to invent even for a demo — ask if the number isn't
   already recorded.
5. **Never guess an ambiguous logging detail.** Portion size, exact timing,
   duration, intensity — ask one lightweight clarifying question rather
   than filling in a plausible-sounding value. Don't block on an answer if
   a reasonable default is fine.
6. **One row per exercise / meal / measurement, always.** Never a
   session-level summary row — see Schema and tools below for why.
7. **Read the training split dynamically, every time.** Never hardcode
   which weekdays are training vs. rest, or what each day's focus is — see
   Reference pages below; it has already changed once and will change
   again.

## Schema and tools

- **Workouts** — one exercise per row: `name`, `date`, `duration_min`,
  `exercises` (the set/rep/weight scheme, e.g. "4x10 @ moderate-heavy, RPE
  7-8"), `intensity_rpe`, `notes`, `type` (Strength/Cardio/Yoga/Sports/
  Rest — a Rest day is one row, type=Rest). All fields except
  `name`/`date`/`type` are nullable — a Rest-day row typically only needs
  those three.
  Tools: `workouts_read(date_from?, date_to?, workout_type?)`,
  `workout_write(name, date, workout_type, duration_min?, exercises?, intensity_rpe?, notes?)`,
  `workout_delete(id)`.
- **Meals** — one meal per row: `name`, `date`, `meal`
  (Breakfast/Lunch/Dinner/Snack), `calories`, `protein_g`, `carbs_g`,
  `fat_g`, `notes`. Macro fields are nullable — a skeleton entry (meal
  logged, macros not yet known) is expected and should be flagged as
  incomplete, not treated as missing.
  Tools: `meals_read(date_from?, date_to?, meal?)`,
  `meal_write(name, date, meal, calories?, protein_g?, carbs_g?, fat_g?, notes?)`,
  `meal_update(id, calories?, protein_g?, carbs_g?, fat_g?, notes?)`,
  `meal_delete(id)` — use
  `meal_update` to fill in or correct an already-logged meal's macros
  (only the fields you pass change); use `meal_write` only for a genuinely
  new meal. Calling `meal_write` again for a meal type already logged that
  day creates a duplicate row — always check `meals_read` first; if a
  duplicate is created by mistake, remove it with `meal_delete`. `meal_update`
  cannot clear a field back to null, and cannot change name/date/meal — only
  calories/protein_g/carbs_g/fat_g/notes.
- **Body Metrics** — one measurement/check-in per row: `measurement`,
  `date`, `weight_lbs`, `body_fat_pct`, `sleep_hrs`, `resting_hr`,
  `waist_in`, `height_in`, `notes`. All biometric fields are nullable.
  Tools: `body_metrics_read(date_from?, date_to?)`,
  `body_metric_write(measurement, date, weight_lbs?, body_fat_pct?, sleep_hrs?, resting_hr?, waist_in?, height_in?, notes?)`,
  `body_metric_delete(id)`.
  `body_metric_write` is insert-only, by design: a new same-day row is
  expected when the user gives updated numbers — readers always take the
  latest entry for a date, so there's no need to find-and-update an
  existing row (unlike meals, where each meal type is its own distinct
  entry worth correcting in place). This is only about genuinely new
  numbers, though — a mistyped or erroneous check-in row can be removed
  with `body_metric_delete` rather than left to skew history.
- **Aggregates** — `daily_summary(date)` returns
  `{workouts: [...], meals: [...], body_metric: {...}|null}` for a single
  literal date — call this instead of building any kind of "today"
  dashboard; there's no view-refresh mechanism to maintain, just call it
  fresh each time. `weekly_totals(week_start)` returns
  `{calories, protein_g, carbs_g, fat_g, workout_days, workout_count}` for
  the 7-day window starting `week_start`; `workout_days` excludes
  Rest-type rows, `workout_count` includes them.

All dates are `YYYY-MM-DD`.

## Reference pages still in Notion (not migrated)

Only the three logging databases above moved to Postgres. These remain in
Notion:

- **🎯 Goals** (`3a171330-52bb-8181-bbb8-d7dce5eeece1`) — physique/fat-loss
  goals, milestones, and tracking-habit expectations. Read this before
  generating any plan.
- **⚙️ Preferences & Agent Config** (`3a171330-52bb-81b1-aa62-c7deca0a2865`)
  — the current training split (which weekdays are training vs. rest, and
  each day's focus), user preferences (training style, gym access,
  experience level, injury status). **Always read the split from here at
  runtime — never hardcode which days are training vs. rest.**
- **📝 Notes & Resources** (`3a371330-52bb-81b2-82e8-c7497f8094b2`) — the
  user's own free-form notes.
- Hub page: **🏋️ Health & Fitness** (`3a171330-52bb-8188-a744-ed15b5e29d4d`).

The old **🏠 Today** page and its three per-database views are retired —
`daily_summary(date)` replaces what that page did, with no separate
view-refresh mechanism to maintain.

## Workflow: planning or logging a workout

1. **Pull recent history** — call `workouts_read` for the last 7-14 days
   (`date_from`/`date_to`), not just today.
2. **Read the split** — fetch the Preferences & Agent Config page for
   today's training focus (or rest), and the Goals page for the physique/
   fat-loss target and any standing constraints.
3. **Check current health status** — call `body_metrics_read` for recent
   entries and weigh anything the user just said in conversation (pain,
   illness, poor sleep). A constraint stated in conversation right now
   outranks anything in history.
4. **Apply training principles**: 48h+ recovery before repeating a muscle
   group hard, progress load/volume modestly if the last RPE was sub-8,
   rotate movement patterns across the week per the split, and let health
   constraints override the default plan rather than working around them.
5. **Write one row per exercise** via `workout_write`, all sharing that
   day's date.
6. **Don't guess personal biometric facts.** If something like current
   weight or body fat is needed and isn't recorded, ask — don't fabricate
   a plausible-sounding number.

## Workflow: logging a meal or check-in

1. Write one row per meal (`meal_write`) or one row per check-in
   (`body_metric_write`), dated to when it happened. If correcting or
   completing an already-logged meal, use `meal_update` instead of
   writing a new row.
2. If a detail needed for an accurate entry is missing or ambiguous
   (portion size, exact timing), ask a short clarifying question rather
   than guessing — don't record something as confirmed fact if you're not
   confident in it.
3. Keep clarifying questions lightweight — one quick question, not an
   interrogation, and don't block on an answer if a reasonable default
   works.

## Things intentionally not built (don't reintroduce without reason)

A combined "Day Log" table with relations back to Workouts/Meals/Body
Metrics, and individual per-day pages with manual navigation, were tried
in the old Notion setup and removed in favor of the simpler structure
above — `daily_summary(date)` gives the same "what happened today" view
without a separate table to keep in sync. If asked to rebuild something
like this, treat it as a real request, not an oversight, and recheck
whether today's simpler structure has stopped being sufficient first.

---
name: software-development
description: "Standing workflow for starting a new software/code project: bootstrap local git, create a GitHub repo via the github backend, and keep upstream in sync as work progresses."
tags: [github, git, dev-workflow, bootstrap]
---

# Software Development — New Project Bootstrap & Upstream Discipline

This applies whenever the user starts a new software or code project — a
new codebase, script, or app, not incremental work on an existing repo.

## Step 0: check before creating

Before bootstrapping anything, check whether this project already has a
local repo (`.git` present) or a configured `origin` remote, or whether a
matching GitHub repo already exists. Only run the bootstrap below if none
of these exist yet — a project resumed across sessions should never end up
with a second, duplicate GitHub repo.

## Step 1: local bootstrap

- `git init` if no `.git` directory exists yet.
- A short README: project name plus a one-line description. Nothing more
  prescriptive than that — no fixed section template.
- A `.gitignore` appropriate to the detected stack (language/framework
  found in the project files).

## Step 2: create the GitHub repo

Use `search_tools`/`call_tool` to reach the `github` backend — never
assume a tool name without discovering it first, e.g.:

```
search_tools(query="create a github repository")
call_tool(server="github", tool="<discovered tool>", arguments={...})
```

- Private by default, unless the user says otherwise.
- Never guess or hardcode a repo owner/org — defer to whatever the
  `github` backend's credentials resolve to by default.

## Step 3: wire remote and push

- Add the new repo as the `origin` remote.
- Initial commit (README, `.gitignore`, and whatever else already exists
  locally), then push.

## Core principles

These are standing constraints, not suggestions:

1. **Push after each logical unit of work** — a completed feature, fix, or
   coherent group of changes — rather than letting local commits pile up
   unpushed. Upstream should stay close to real-time with the local repo.
2. **Private by default.** Only make a repo public if the user says so.
3. **Never guess an owner/org.** Use the `github` backend's own default
   rather than hardcoding one.
4. **Ask before anything hard to reverse** — force-push, history rewrite,
   deleting a repo or branch — same as the general rule for any
   hard-to-reverse or shared-visibility action.
5. **Don't duplicate a project's GitHub repo.** Re-check Step 0 whenever
   resuming work on a project you didn't just bootstrap yourself.

Applying these principles to a specific moment (the first commit of a new
project, a routine push mid-session) is left to your own judgment — there
is deliberately no separate step-by-step section per scenario here.

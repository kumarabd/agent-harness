---
name: travel-planner
description: "Use TREK (the trek backend's tools/resources) as the source of truth for planning and managing trips/vacations — itineraries, places, budget, packing, reservations, collaboration — instead of ad-hoc notes or guessing structure."
tags: [travel, trips, vacation, planning, trek]
---

# Travel Planning — TREK

This user plans and tracks trips/vacations in TREK, a self-hosted travel
planner, reachable through mcp-hub's `trek` backend. Use
`search_tools`/`call_tool` (`server="trek"`) to reach its resources and
tools — never assume a tool or resource name without discovering it first.
TREK exposes a large, versioned surface (~150 tools across trips, places,
itinerary days, budget, packing, reservations, collaboration, and several
addon-gated areas) that this skill deliberately does not enumerate in
full — discover the exact tool for the task at hand via `search_tools`
rather than relying on a name recalled here, since it can drift as TREK
is upgraded.

## Starting point for any trip

1. `list_trips` — find the trip you're working with (or confirm one
   doesn't exist yet before creating it). Supports `include_archived`.
2. `get_trip_summary` — the context loader. Returns a full denormalized
   snapshot (metadata, members, days with assignments/notes,
   accommodations, budget, packing, reservations, collab notes, to-dos,
   poll/message counts) in one call. Call this before making non-trivial
   edits to an existing trip — trip state changes in real time via the
   web UI and other collaborators, so don't rely on what you last saw in
   conversation.

## Core principles

These are standing constraints, not suggestions:

1. **TREK is the default recording surface for trip planning.** Write
   itinerary, budget, packing, and reservation details into TREK rather
   than leaving them only in chat, without being asked each time.
2. **Never guess a trip/day/place/item ID.** Resolve it first via
   `list_trips`, `get_trip_summary`, or the relevant `list_*` tool —
   these IDs aren't predictable and a wrong one silently edits the wrong
   record.
3. **Prefer compound tools when creating something new**:
   `create_and_assign_place`, `create_place_accommodation`,
   `create_budget_item_with_members` each wrap two operations in one
   atomic call. Only use them when the place/item doesn't already exist —
   if it does, call the individual tools directly (`assign_place_to_day`,
   `create_accommodation`, `set_budget_item_members`) instead of creating
   a duplicate.
4. **Reservations and transport bookings are created `pending` by
   default.** Only set `status: "confirmed"` when the user actually says
   it's booked/confirmed — don't assume.
5. **No image uploads through MCP.** If a trip needs a cover image, tell
   the user to set it via the web UI — this isn't something to work
   around.
6. **Addon-gated tools can be unavailable.** Atlas, Collab, Vacay, and
   Journey tools/resources only work if an admin has enabled that addon
   *and* (for OAuth sessions) the matching scope was granted. If a call
   fails as unavailable/out-of-scope, say so plainly and name what's
   needed (addon enablement or a scope re-grant) rather than retrying
   blindly or silently dropping the request.
7. **Don't fabricate a real-world fact** (coordinates, prices, opening
   hours, flight/airport codes). Use `search_place` / `search_airports` /
   `get_place_details` to resolve real data, or ask the user — never
   invent a plausible-looking value for something meant to be booked or
   navigated to.

## Feature areas (where to look)

A condensed map — use `search_tools` for the exact tool name once you
know which area you need:

| Area | Covers |
|---|---|
| Trips | create/update/delete, members, share links, `copy_trip`, `.ics` export |
| Places | POIs, categories, search/import from a shared Maps URL |
| Day Planning | days, assigning/ordering/timing places within a day |
| Accommodations / Transport / Reservations | hotels, flights/trains/cars/cruises, other bookings |
| Budget | expenses, per-member splits, settlement suggestions |
| Packing | checklist items, bags, templates, per-category assignees |
| Day Notes / To-Dos / Tags | day-level notes, task lists, user-scoped tags |
| Notifications | in-app notification list/read state |
| Maps & Weather / Airports | geocoding, weather forecast, airport lookup |
| Collab *(addon)* | shared notes, polls, chat |
| Atlas *(addon)* | visited countries/regions, bucket list, stats |
| Vacay *(addon)* | shared vacation-day planning, holiday calendars |
| Journey *(addon)* | multi-trip journeys/entries linking several trips together |

## Workflow: planning a new trip

1. Confirm it doesn't already exist (`list_trips`) before creating one.
2. `create_trip` (title, dates, currency) — days are auto-generated from
   the date range.
3. Research and add places with real coordinates (`search_place` /
   `get_place_details`), then build the day-by-day itinerary
   (`create_and_assign_place`, `update_assignment_time`,
   `reorder_day_assignments`).
4. Book accommodations/transport/reservations as needed (pending by
   default — see Core principles above).
5. Put together a budget (`create_budget_item_with_members`) and packing
   list (`bulk_import_packing` / `apply_packing_template`) suited to the
   trip.
6. Call `get_trip_summary` at the end and recap what was added — don't
   assume the user is tracking every individual tool call.

Applying this to a specific task (a quick single-day-plan tweak vs. a
full week-long build-out) is left to your own judgment — there is
deliberately no separate step-by-step section per task size.

---
name: user-profile
description: "Where to find ambient, current-state facts about the user (timezone, location, vehicle) in Notion — read this instead of asking or guessing."
tags: [profile, timezone, location, notion]
---

# User Profile — Ambient Facts

The user keeps a small set of current-state facts in Notion, separate from
any single bot's domain (health, etc.) — anything that "just being who/where
the user currently is" rather than a task or a log entry.

**Page**: 🪪 Profile (`3a371330-52bb-8197-b51b-efaafffb0ad8`)
**Database**: Profile (data source `f49e5af5-cf78-4469-aa20-9fd03b227eef`),
nested inside the page above — a single row holding the current facts.
Query it directly (SQL or fetch) rather than parsing page text.

## What's there

Columns on that one row: `Name`, `Current Location`, `Timezone` (IANA-style,
e.g. "America/Los_Angeles"), `Vehicle`, `Last Updated`.

More columns may be added over time — check the data source's actual schema
rather than assuming this list is exhaustive.

## When to use

- Before scheduling anything time-sensitive (a cron, a reminder, "remind me
  at 5pm") — read the timezone here rather than guessing from indirect
  context clues (git commit offsets, city names mentioned in passing, etc.)
  or asking the user something they've already told you once.
- Before a location-relevant task (directions, weather, "what's nearby") —
  read the current location here first; only ask if the task needs a
  *different* location than where the user currently is.
- Vehicle-relevant tasks (fuel type for gas-station search, charging for
  EVs, maintenance reminders) — read the vehicle here.

## Keeping it current

These are facts that change over time (the user moves, gets a different
car, timezone shifts on travel). **If the user tells you something here has
changed, update that field on the existing row immediately** — don't add a
new row, and don't just remember the new value for the current conversation
and leave Notion stale. Any other bot or session reading this later needs
the current fact, not what was true when you learned it.

Don't guess or fabricate a value that isn't on the page and wasn't just
stated by the user — ask, the same way you would for any other personal
fact you're not confident about.

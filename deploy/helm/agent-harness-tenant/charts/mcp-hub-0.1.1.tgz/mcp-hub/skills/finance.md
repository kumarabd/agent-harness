---
name: finance
description: "How this user's finances are structured in Postgres (via the finance backend's tools), and the standing principles for logging transactions, bills, and account balances."
tags: [finance, budgeting, postgres]
---

# Finance — Postgres Structure & Principles

This user tracks personal finances in a dedicated Postgres database, reachable
through mcp-hub's `finance` backend. Use `search_tools`/`call_tool` to reach
its tools — never assume a tool name without discovering it first.

## Schema and tools

All dates are `YYYY-MM-DD`; months are `YYYY-MM`.

- **Transactions** — one row per transaction: `name`, `date`, `amount`,
  `category`, `account`, `notes`.
  Tools: `transactions_read(date_from?, date_to?, category?, account?)`,
  `transaction_write(name, date, amount, category?, account?, notes?)`,
  `transaction_delete(id)`.
- **Bills & Subscriptions** — one row per bill: `name`, `amount`,
  `billing_cycle` (Weekly/Monthly/Yearly), `due_date`, `category`, `status`
  (Active/Cancelled), `notes`.
  Tools: `bills_read(status?, category?)`,
  `bill_write(name, amount, billing_cycle, due_date, category?, status?, notes?)`,
  `bill_delete(id)`.
- **Accounts / Net Worth** — one row per account *per snapshot date*, never a
  running summary: `account`, `type` (Checking/Savings/Credit/Investment/Loan),
  `balance`, `date`, `notes`. Record Credit and Loan balances as negative
  numbers — `net_worth_summary` sums balances directly.
  Tools: `accounts_read(account?, account_type?, date_from?, date_to?)`,
  `account_write(account, account_type, balance, date, notes?)`,
  `account_delete(id)`.
- **Budgets** — category limits: `category`, `monthly_limit`, `notes`. Always
  call `budgets_read()` fresh — never hardcode a limit recalled from an
  earlier turn, since it can change.
  Tools: `budgets_read()`, `budget_write(category, monthly_limit, notes?)`,
  `budget_delete(category)`.
- **Aggregates** — for math that's error-prone to do by summing rows
  yourself: `spending_by_category(month)` (format `YYYY-MM`, returns
  `{category: total}`) and `net_worth_summary(as_of?)` (returns
  `{total, by_account}`, using the latest balance snapshot per account as of
  the given date or today).

## Core principles

These are standing constraints, not suggestions:

1. **The finance tools are the default recording surface.** Log
   transactions, bills, and balance snapshots there without being asked each
   time.
2. **Never guess or fabricate a dollar amount, balance, or due date.** Ask
   if it isn't already known or stated — these are real facts about the
   user's finances, not something to estimate.
3. **One row per transaction, per bill, or per account-balance snapshot.**
   Never a rollup or summary row — see the Accounts/Net Worth structure
   above for why (history and trend queries depend on one row per
   snapshot). Use `spending_by_category`/`net_worth_summary` for totals
   instead of trying to compute them across many rows yourself.
4. **Ask about ambiguous categorization** (e.g. "Dining" vs. "Groceries")
   with one lightweight clarifying question rather than guessing. Don't
   block on an answer if a reasonable default is fine.
5. **Read budgets and limits fresh via `budgets_read()` before commenting
   on spending.** Don't rely on a stale recollection of what a budget was —
   it can change over time.
6. **Flag noticed cost creep** (a subscription price increase, a new
   recurring charge) when you see it in the data.

Applying these principles to a specific task (logging a purchase,
reviewing this month's spending, checking on a bill) is left to your own
financial judgment — there is deliberately no separate step-by-step
workflow section per task type here.
